'use strict';

window.addEventListener('load', function () {

  console.log("Marina up and running!");

});